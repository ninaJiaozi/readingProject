/**
 * @Author guojiajia
 * @Date 2017/8/11
 * 此次手机端屏幕适配主要以iphone6屏幕宽度为标准，375px。更改屏幕之后需刷新才能重新获取屏幕宽度
 */
window.onload = function () {
    /*屏幕适配*/
    var deviceWidth = document.documentElement.clientWidth;
    document.documentElement.style.fontSize = deviceWidth / 7.5 + 'px';

    /*判断是否显示横向滚动条及百分比球*/
    var clientHeight = document.documentElement.clientHeight;
    var content = document.getElementById("content");
    var scrollBar = document.getElementsByClassName("scrollBar")[0];
    var sideBall = document.getElementsByClassName("sideBall")[0];
    if(content.offsetHeight > clientHeight){
        scrollBar.style.display = "block";
        sideBall.style.display = "block";
    }

    /*显示进度小球*/
    setTimeout(function(){
        document.getElementsByClassName("scrollBar")[0].style.right = '.3rem';
        document.getElementsByClassName("sideBall")[0].style.right = '0';
    },200);


    /*使用技巧modal控制*/
    var flag = true;
    var skillModal = document.getElementsByClassName("skillModal")[0];
    var skillBtn = document.getElementsByClassName("skill")[0];
    var close = document.getElementsByClassName('close')[0];
    function isShowModal(e) {
        flag = !flag;
        if(flag == true){
            skillModal.style.left = '0';
        }else{
            skillModal.style.left = '-4rem';
        }
    }
    skillBtn.addEventListener('click',isShowModal);
    close.addEventListener('click',function(event){
        skillModal.style.left = '-4rem';
        flag = false;
    });


    /*获取content的偏移高度*/
    function getRect(ele){
        var top = ele.getBoundingClientRect().top;
        return {
            y:top + getScrollTop(),
            height:ele.offsetHeight
        }
    }
    function getScrollTop() {
        return Math.max(document.documentElement.scrollTop, document.body.scrollTop);
    }
    function getViewHeight() {
        return Math.min(document.documentElement.clientHeight, document.body.clientHeight);
    }

    var scrollBtn = document.getElementById("scrollBtn");
    var progress = document.getElementById("progress");
    var y = getRect(content).y;
    var contentHeight = getRect(content).height;
    var viewHeight = getViewHeight();
    var currentHeight = contentHeight - viewHeight;
    var percent = document.getElementById("percent");
    /*滚动事件*/
    window.onscroll = function () {
        var scrollTop = getScrollTop();
        var newProgress = (scrollTop - y) / currentHeight;
        if(newProgress >= 0 && newProgress <= 1){
            percent.innerHTML = Math.ceil(newProgress*100) + '%';
            scrollBtn.style.left = Math.ceil(newProgress*100) + '%';
            progress.style.width = Math.ceil(newProgress*100) + '%';
        } else if(newProgress < 0 ){
            percent.innerHTML = "0%";
            scrollBtn.style.left = '0%';
            progress.style.width = '0%';
        } else {
            percent.innerHTML = "100%";
            scrollBtn.style.left = '98%';
            progress.style.width = '100%';
        }
    };


    /*判断是否是移动端*/
    function isMobile() {
        var clientArray = ['Android','iPhone','iPad','iPod','Windows Phone']
        var agentInfo = navigator.userAgent;
        var isMobile = false;
        for(var i=0;i<clientArray.length;i++){
            if(agentInfo.indexOf(clientArray[i]) > 0){
                isMobile = true;
                break;
            }
        }
        return isMobile
    }

    /*进度条拖动事件*/
    var totalProgress = document.getElementsByClassName("scrollProgress")[0];
    var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    scrollBtn.onmousedown = function(){
        document.onmousemove = function(){
            dragPro(event)
        };
    };
    document.onmouseup = function(){
        document.onmousemove = null;
    };
    function dragPro(event){
        if(isMobile()==true){
            var newProgress = (event.changedTouches[0].clientX-scrollBar.offsetLeft)/totalProgress.offsetWidth * 100;
        }else{
            var newProgress = (event.clientX-scrollBar.offsetLeft)/totalProgress.offsetWidth * 100;
        }

        if(newProgress >= 100){
            percent.innerHTML = '100%';
            scrollBtn.style.left = '98%';
            progress.style.width = '100%';
            document.documentElement.scrollTop = (newProgress * currentHeight + y)/100;
            document.body.scrollTop = (newProgress * currentHeight + y)/100;
        }else if(newProgress <= 0){
            document.documentElement.scrollTop = 0;
            document.body.scrollTop = 0;
        }else{
            percent.innerHTML = Math.ceil(newProgress) + '%';
            scrollBtn.style.left = Math.ceil(newProgress) + '%';
            progress.style.width = Math.ceil(newProgress) + '%';
            document.documentElement.scrollTop = (newProgress * currentHeight + y)/100;
            document.body.scrollTop = (newProgress * currentHeight + y)/100;
        }
    }
    if(isMobile()==true){
        scrollBtn.addEventListener('touchstart',function(){
            scrollBar.addEventListener('touchmove',function(){
                dragPro(event)
            })
        });
        scrollBar.addEventListener('touchend',function(){
            scrollBar.removeEventListener('touchmove',dragPro);
        });
    }
};